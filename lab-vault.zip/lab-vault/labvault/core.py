"""Core of LAB Vault: hybrid post-quantum file encryption.

Suite "LABV1":
  * Key establishment : ML-KEM-768 (FIPS 203) + X25519, combined with HKDF-SHA256
  * Data encryption   : AES-256-GCM, chunked (STREAM construction)
  * Signatures        : ML-DSA-65 (FIPS 204) over a SHA3-512 digest of the file

All primitives come from the `cryptography` package (OpenSSL backend).
Only the composition and file format below are LAB Vault's own, and that
composition has NOT been independently audited.
"""

from __future__ import annotations

import base64
import hashlib
import json
import os
import struct
import tempfile
from dataclasses import dataclass
from typing import BinaryIO, Iterable, Optional

from cryptography.exceptions import InvalidSignature, InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import mldsa, mlkem, x25519
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

MAGIC = b"LABVAULT"
SUITE = "MLKEM768+X25519+HKDF-SHA256+AES256GCM-STREAM+MLDSA65"
DEFAULT_CHUNK = 64 * 1024
MIN_CHUNK = 1024
MAX_CHUNK = 16 * 1024 * 1024
MAX_HEADER = 1024 * 1024
TAG_LEN = 16
SIG_CONTEXT = b"labvault/v1/file-signature"
SCRYPT_N = 2**17  # ~128 MiB, ~0.4 s on a laptop
SCRYPT_R = 8
SCRYPT_P = 1


class VaultError(Exception):
    """Any failure: bad key, wrong passphrase, tampered or truncated file."""


# --------------------------------------------------------------------------- helpers

def _b64(b: bytes) -> str:
    return base64.b64encode(b).decode("ascii")


def _unb64(s: str) -> bytes:
    try:
        return base64.b64decode(s.encode("ascii"), validate=True)
    except Exception as exc:  # noqa: BLE001
        raise VaultError("malformed base64 field") from exc


def _canonical(obj: dict) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":")).encode("utf-8")


def _read_exact(f: BinaryIO, n: int) -> bytes:
    """Read up to n bytes, looping so short reads on pipes are not mistaken for EOF."""
    parts = []
    got = 0
    while got < n:
        b = f.read(n - got)
        if not b:
            break
        parts.append(b)
        got += len(b)
    return b"".join(parts)


def _x_priv_raw(k: x25519.X25519PrivateKey) -> bytes:
    return k.private_bytes(
        serialization.Encoding.Raw,
        serialization.PrivateFormat.Raw,
        serialization.NoEncryption(),
    )


def _x_pub_raw(k: x25519.X25519PublicKey) -> bytes:
    return k.public_bytes(serialization.Encoding.Raw, serialization.PublicFormat.Raw)


def pretty_fp(fp_hex: str) -> str:
    """Human-readable fingerprint: first 32 hex chars in groups of 4."""
    return " ".join(fp_hex[i : i + 4] for i in range(0, 32, 4))


# --------------------------------------------------------------------------- identities

@dataclass(frozen=True)
class PublicIdentity:
    name: str
    x25519: bytes
    mlkem768: bytes
    mldsa65: bytes

    @property
    def fingerprint(self) -> str:
        h = hashlib.sha256()
        h.update(b"labvault/v1/fingerprint")
        h.update(self.x25519 + self.mlkem768 + self.mldsa65)
        return h.hexdigest()

    def to_json(self) -> dict:
        return {
            "format": "labvault-pub-v1",
            "name": self.name,
            "fingerprint": self.fingerprint,
            "x25519": _b64(self.x25519),
            "mlkem768": _b64(self.mlkem768),
            "mldsa65": _b64(self.mldsa65),
        }

    @staticmethod
    def from_json(d: dict) -> "PublicIdentity":
        if d.get("format") != "labvault-pub-v1":
            raise VaultError("not a LAB Vault public key file")
        ident = PublicIdentity(
            name=str(d.get("name", "")),
            x25519=_unb64(d["x25519"]),
            mlkem768=_unb64(d["mlkem768"]),
            mldsa65=_unb64(d["mldsa65"]),
        )
        if len(ident.x25519) != 32 or len(ident.mlkem768) != 1184 or len(ident.mldsa65) != 1952:
            raise VaultError("public key has wrong sizes")
        if d.get("fingerprint") != ident.fingerprint:
            raise VaultError("public key fingerprint does not match its contents")
        return ident

    def save(self, path: str) -> None:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(self.to_json(), f, indent=2)
            f.write("\n")

    @staticmethod
    def load(path: str) -> "PublicIdentity":
        with open(path, "r", encoding="utf-8") as f:
            return PublicIdentity.from_json(json.load(f))


@dataclass(frozen=True)
class PrivateIdentity:
    name: str
    x25519_priv: bytes   # 32 bytes
    mlkem_seed: bytes    # 64 bytes
    mldsa_seed: bytes    # 32 bytes

    @staticmethod
    def generate(name: str) -> "PrivateIdentity":
        return PrivateIdentity(
            name=name,
            x25519_priv=_x_priv_raw(x25519.X25519PrivateKey.generate()),
            mlkem_seed=mlkem.MLKEM768PrivateKey.generate().private_bytes_raw(),
            mldsa_seed=mldsa.MLDSA65PrivateKey.generate().private_bytes_raw(),
        )

    # private key objects
    def _x(self) -> x25519.X25519PrivateKey:
        return x25519.X25519PrivateKey.from_private_bytes(self.x25519_priv)

    def _kem(self) -> mlkem.MLKEM768PrivateKey:
        return mlkem.MLKEM768PrivateKey.from_seed_bytes(self.mlkem_seed)

    def _dsa(self) -> mldsa.MLDSA65PrivateKey:
        return mldsa.MLDSA65PrivateKey.from_seed_bytes(self.mldsa_seed)

    def public(self) -> PublicIdentity:
        return PublicIdentity(
            name=self.name,
            x25519=_x_pub_raw(self._x().public_key()),
            mlkem768=self._kem().public_key().public_bytes_raw(),
            mldsa65=self._dsa().public_key().public_bytes_raw(),
        )

    @property
    def fingerprint(self) -> str:
        return self.public().fingerprint

    # --- passphrase-protected storage: scrypt -> AES-256-GCM
    def save(self, path: str, passphrase: str) -> None:
        if not passphrase:
            raise VaultError("a non-empty passphrase is required")
        pub = self.public()
        salt = os.urandom(16)
        nonce = os.urandom(12)
        kdf = {"name": "scrypt", "n": SCRYPT_N, "r": SCRYPT_R, "p": SCRYPT_P, "salt": _b64(salt)}
        key = Scrypt(salt=salt, length=32, n=SCRYPT_N, r=SCRYPT_R, p=SCRYPT_P).derive(
            passphrase.encode("utf-8")
        )
        aad = b"labvault/v1/keyfile" + bytes.fromhex(pub.fingerprint) + _canonical(kdf)
        secret = self.x25519_priv + self.mlkem_seed + self.mldsa_seed
        ct = AESGCM(key).encrypt(nonce, secret, aad)
        doc = {
            "format": "labvault-key-v1",
            "name": self.name,
            "fingerprint": pub.fingerprint,
            "kdf": kdf,
            "nonce": _b64(nonce),
            "ciphertext": _b64(ct),
        }
        fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(doc, f, indent=2)
            f.write("\n")

    @staticmethod
    def load(path: str, passphrase: str) -> "PrivateIdentity":
        with open(path, "r", encoding="utf-8") as f:
            d = json.load(f)
        if d.get("format") != "labvault-key-v1":
            raise VaultError("not a LAB Vault private key file")
        kdf = d["kdf"]
        if kdf.get("name") != "scrypt":
            raise VaultError("unsupported key derivation")
        n, r, p = int(kdf["n"]), int(kdf["r"]), int(kdf["p"])
        if n < 2**14 or n > 2**22 or r < 1 or r > 16 or p < 1 or p > 16:
            raise VaultError("refusing unreasonable scrypt parameters")
        key = Scrypt(salt=_unb64(kdf["salt"]), length=32, n=n, r=r, p=p).derive(
            passphrase.encode("utf-8")
        )
        aad = b"labvault/v1/keyfile" + bytes.fromhex(d["fingerprint"]) + _canonical(kdf)
        try:
            secret = AESGCM(key).decrypt(_unb64(d["nonce"]), _unb64(d["ciphertext"]), aad)
        except InvalidTag as exc:
            raise VaultError("wrong passphrase, or the key file was modified") from exc
        if len(secret) != 32 + 64 + 32:
            raise VaultError("key file has wrong size")
        ident = PrivateIdentity(d.get("name", ""), secret[:32], secret[32:96], secret[96:])
        if ident.fingerprint != d["fingerprint"]:
            raise VaultError("key file fingerprint mismatch")
        return ident


# --------------------------------------------------------------------------- key wrapping

def _kek(ss_x: bytes, ss_k: bytes, epk: bytes, kct: bytes, rx: bytes, rk: bytes) -> bytes:
    """Hybrid combiner: both shared secrets plus the full transcript go through HKDF.

    An attacker must break BOTH X25519 and ML-KEM-768 to learn the key.
    """
    salt = hashlib.sha256(b"labvault/v1/kek-salt" + epk + kct + rx + rk).digest()
    return HKDF(
        algorithm=hashes.SHA256(), length=32, salt=salt, info=b"labvault/v1/kek"
    ).derive(ss_x + ss_k)


def _wrap_dek(dek: bytes, rcpt: PublicIdentity) -> dict:
    eph = x25519.X25519PrivateKey.generate()
    epk = _x_pub_raw(eph.public_key())
    ss_x = eph.exchange(x25519.X25519PublicKey.from_public_bytes(rcpt.x25519))
    ss_k, kct = mlkem.MLKEM768PublicKey.from_public_bytes(rcpt.mlkem768).encapsulate()
    kek = _kek(ss_x, ss_k, epk, kct, rcpt.x25519, rcpt.mlkem768)
    nonce = os.urandom(12)
    wdek = AESGCM(kek).encrypt(nonce, dek, b"labvault/v1/wrap" + bytes.fromhex(rcpt.fingerprint))
    return {
        "fp": rcpt.fingerprint,
        "epk": _b64(epk),
        "kct": _b64(kct),
        "nonce": _b64(nonce),
        "wdek": _b64(wdek),
    }


def _unwrap_dek(entry: dict, ident: PrivateIdentity) -> bytes:
    pub = ident.public()
    epk = _unb64(entry["epk"])
    kct = _unb64(entry["kct"])
    if len(epk) != 32 or len(kct) != 1088:
        raise VaultError("malformed recipient entry")
    ss_x = ident._x().exchange(x25519.X25519PublicKey.from_public_bytes(epk))
    ss_k = ident._kem().decapsulate(kct)
    kek = _kek(ss_x, ss_k, epk, kct, pub.x25519, pub.mlkem768)
    try:
        return AESGCM(kek).decrypt(
            _unb64(entry["nonce"]),
            _unb64(entry["wdek"]),
            b"labvault/v1/wrap" + bytes.fromhex(pub.fingerprint),
        )
    except InvalidTag as exc:
        raise VaultError("could not unlock the file key (corrupt header or wrong key)") from exc


# --------------------------------------------------------------------------- streaming AEAD

def _chunk_nonce(prefix: bytes, counter: int, last: bool) -> bytes:
    if counter >= 2**32:
        raise VaultError("file too large for this chunk size")
    return prefix + struct.pack(">IB", counter, 1 if last else 0)


def _sig_digest_start(hb: bytes) -> "hashlib._Hash":
    h = hashlib.sha3_512()
    h.update(b"labvault/v1/file-digest")
    h.update(struct.pack(">I", len(hb)))
    h.update(hb)
    return h


# --------------------------------------------------------------------------- encrypt

def encrypt_stream(
    src: BinaryIO,
    dst: BinaryIO,
    recipients: Iterable[PublicIdentity],
    signer: Optional[PrivateIdentity] = None,
    chunk_size: int = DEFAULT_CHUNK,
) -> None:
    recipients = list(recipients)
    if not recipients:
        raise VaultError("at least one recipient is required")
    if not (MIN_CHUNK <= chunk_size <= MAX_CHUNK):
        raise VaultError("chunk size out of range")
    seen = set()
    for r in recipients:
        if r.fingerprint in seen:
            raise VaultError("duplicate recipient")
        seen.add(r.fingerprint)

    dek = os.urandom(32)
    prefix = os.urandom(7)
    header = {
        "v": 1,
        "suite": SUITE,
        "chunk": chunk_size,
        "prefix": _b64(prefix),
        "recipients": [_wrap_dek(dek, r) for r in recipients],
        "signed": None,
    }
    sig_len = 0
    if signer is not None:
        sig_len = 3309  # ML-DSA-65 signature size
        header["signed"] = {"alg": "ML-DSA-65", "signer": signer.fingerprint, "sig_len": sig_len}
    hb = _canonical(header)

    dst.write(MAGIC + struct.pack(">I", len(hb)) + hb)
    digest = _sig_digest_start(hb) if signer else None
    aead = AESGCM(dek)
    aad = hashlib.sha256(hb).digest()

    cur = _read_exact(src, chunk_size)
    counter = 0
    while True:
        nxt = _read_exact(src, chunk_size) if len(cur) == chunk_size else b""
        last = not nxt
        ct = aead.encrypt(_chunk_nonce(prefix, counter, last), cur, aad)
        dst.write(ct)
        if digest:
            digest.update(ct)
        if last:
            break
        cur, counter = nxt, counter + 1

    if signer:
        sig = signer._dsa().sign(digest.digest(), SIG_CONTEXT)
        if len(sig) != sig_len:
            raise VaultError("unexpected signature size")
        dst.write(sig)


# --------------------------------------------------------------------------- decrypt

def read_header(f: BinaryIO) -> tuple[dict, bytes, int]:
    """Parse and sanity-check the header. Returns (header, header_bytes, data_start)."""
    if _read_exact(f, len(MAGIC)) != MAGIC:
        raise VaultError("not a LAB Vault file")
    raw_len = _read_exact(f, 4)
    if len(raw_len) != 4:
        raise VaultError("truncated file")
    (hlen,) = struct.unpack(">I", raw_len)
    if hlen == 0 or hlen > MAX_HEADER:
        raise VaultError("invalid header length")
    hb = _read_exact(f, hlen)
    if len(hb) != hlen:
        raise VaultError("truncated header")
    try:
        header = json.loads(hb.decode("utf-8"))
    except Exception as exc:  # noqa: BLE001
        raise VaultError("corrupt header") from exc
    if hb != _canonical(header):
        raise VaultError("header is not in canonical form")
    if header.get("v") != 1 or header.get("suite") != SUITE:
        raise VaultError("unsupported file version or cipher suite")
    chunk = header.get("chunk")
    if not isinstance(chunk, int) or not (MIN_CHUNK <= chunk <= MAX_CHUNK):
        raise VaultError("invalid chunk size")
    if len(_unb64(header.get("prefix", ""))) != 7:
        raise VaultError("invalid nonce prefix")
    if not isinstance(header.get("recipients"), list) or not header["recipients"]:
        raise VaultError("no recipients in header")
    return header, hb, len(MAGIC) + 4 + hlen


def inspect_file(path: str) -> dict:
    with open(path, "rb") as f:
        header, _, _ = read_header(f)
    return {
        "suite": header["suite"],
        "chunk_size": header["chunk"],
        "recipients": [r["fp"] for r in header["recipients"]],
        "signed_by": (header["signed"] or {}).get("signer"),
        "size_bytes": os.path.getsize(path),
    }


def decrypt_file(
    path_in: str,
    path_out: str,
    identity: PrivateIdentity,
    sender: Optional[PublicIdentity] = None,
    allow_unverified: bool = False,
    overwrite: bool = False,
) -> dict:
    """Decrypt path_in to path_out. Nothing is left at path_out unless every chunk
    authenticates and the final-chunk marker is present (so truncation is detected).
    """
    if os.path.exists(path_out) and not overwrite:
        raise VaultError(f"refusing to overwrite existing file: {path_out}")

    size = os.path.getsize(path_in)
    with open(path_in, "rb") as src:
        header, hb, data_start = read_header(src)
        signed = header.get("signed")

        # --- signature policy
        sig_len = 0
        if signed:
            sig_len = int(signed["sig_len"])
            if signed.get("alg") != "ML-DSA-65" or sig_len != 3309:
                raise VaultError("unsupported signature algorithm")
        if sender is not None and not signed:
            raise VaultError("a sender was given but this file is not signed")
        if signed and sender is None and not allow_unverified:
            raise VaultError(
                "file is signed by %s; supply the sender's public key to verify it, "
                "or explicitly allow unverified decryption" % pretty_fp(signed["signer"])
            )

        region = size - data_start - sig_len
        chunk = header["chunk"]
        full = chunk + TAG_LEN
        if region < TAG_LEN or (region % full) and (region % full) < TAG_LEN:
            raise VaultError("file is truncated or corrupt")

        # --- verify signature BEFORE releasing any plaintext
        if signed and sender is not None:
            if signed["signer"] != sender.fingerprint:
                raise VaultError("file was signed by a different key than the sender given")
            digest = _sig_digest_start(hb)
            src.seek(data_start)
            remaining = region
            while remaining:
                b = src.read(min(1 << 20, remaining))
                if not b:
                    raise VaultError("file is truncated")
                digest.update(b)
                remaining -= len(b)
            sig = _read_exact(src, sig_len)
            try:
                mldsa.MLDSA65PublicKey.from_public_bytes(sender.mldsa65).verify(
                    sig, digest.digest(), SIG_CONTEXT
                )
            except InvalidSignature as exc:
                raise VaultError("SIGNATURE INVALID: file was modified or not from this sender") from exc

        # --- unwrap the file key
        entry = next((r for r in header["recipients"] if r.get("fp") == identity.fingerprint), None)
        if entry is None:
            raise VaultError("this key is not an intended recipient of the file")
        dek = _unwrap_dek(entry, identity)
        aead = AESGCM(dek)
        aad = hashlib.sha256(hb).digest()
        prefix = _unb64(header["prefix"])

        # --- decrypt chunk by chunk into a temp file, then atomically move into place
        out_dir = os.path.dirname(os.path.abspath(path_out))
        fd, tmp = tempfile.mkstemp(dir=out_dir, prefix=".labvault-")
        ok = False
        try:
            with os.fdopen(fd, "wb") as dst:
                src.seek(data_start)
                remaining, counter, total = region, 0, 0
                while remaining > 0:
                    n = min(full, remaining)
                    ct = _read_exact(src, n)
                    if len(ct) != n:
                        raise VaultError("file is truncated")
                    remaining -= n
                    last = remaining == 0
                    try:
                        pt = aead.decrypt(_chunk_nonce(prefix, counter, last), ct, aad)
                    except InvalidTag as exc:
                        raise VaultError(
                            "FILE CORRUPTED OR TAMPERED WITH (chunk %d failed authentication)" % counter
                        ) from exc
                    dst.write(pt)
                    total += len(pt)
                    counter += 1
            os.chmod(tmp, 0o600)
            os.replace(tmp, path_out)
            ok = True
        finally:
            if not ok and os.path.exists(tmp):
                os.unlink(tmp)

    return {
        "plaintext_bytes": total,
        "signature_verified": bool(signed and sender is not None),
        "signed_by": (signed or {}).get("signer"),
    }


def encrypt_file(
    path_in: str,
    path_out: str,
    recipients: Iterable[PublicIdentity],
    signer: Optional[PrivateIdentity] = None,
    chunk_size: int = DEFAULT_CHUNK,
    overwrite: bool = False,
) -> None:
    if os.path.exists(path_out) and not overwrite:
        raise VaultError(f"refusing to overwrite existing file: {path_out}")
    out_dir = os.path.dirname(os.path.abspath(path_out))
    fd, tmp = tempfile.mkstemp(dir=out_dir, prefix=".labvault-")
    ok = False
    try:
        with open(path_in, "rb") as src, os.fdopen(fd, "wb") as dst:
            encrypt_stream(src, dst, recipients, signer, chunk_size)
        os.chmod(tmp, 0o600)
        os.replace(tmp, path_out)
        ok = True
    finally:
        if not ok and os.path.exists(tmp):
            os.unlink(tmp)
