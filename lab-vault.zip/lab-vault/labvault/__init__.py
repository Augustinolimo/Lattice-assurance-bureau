"""LAB Vault - hybrid post-quantum file encryption (unaudited)."""

from .core import (  # noqa: F401
    PrivateIdentity,
    PublicIdentity,
    VaultError,
    decrypt_file,
    encrypt_file,
    encrypt_stream,
    inspect_file,
)

__version__ = "0.1.0"
