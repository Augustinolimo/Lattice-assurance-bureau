"""Command-line interface: `python -m labvault ...`"""

from __future__ import annotations

import argparse
import getpass
import os
import sys

from .core import (
    DEFAULT_CHUNK,
    PrivateIdentity,
    PublicIdentity,
    VaultError,
    decrypt_file,
    encrypt_file,
    inspect_file,
    pretty_fp,
)


def _passphrase(args, confirm: bool = False) -> str:
    if getattr(args, "passphrase_file", None):
        with open(args.passphrase_file, "r", encoding="utf-8") as f:
            return f.read().rstrip("\r\n")
    env = os.environ.get("LABVAULT_PASSPHRASE")
    if env:
        return env
    pw = getpass.getpass("Passphrase: ")
    if confirm and getpass.getpass("Repeat passphrase: ") != pw:
        raise VaultError("passphrases did not match")
    return pw


def cmd_keygen(args) -> int:
    pw = _passphrase(args, confirm=True)
    if len(pw) < 12:
        raise VaultError("use a passphrase of at least 12 characters")
    base = os.path.join(args.out_dir, args.name)
    key_path, pub_path = base + ".key.json", base + ".pub.json"
    for p in (key_path, pub_path):
        if os.path.exists(p):
            raise VaultError(f"refusing to overwrite {p}")
    ident = PrivateIdentity.generate(args.name)
    ident.save(key_path, pw)
    ident.public().save(pub_path)
    print(f"Private key (keep secret, back it up): {key_path}")
    print(f"Public key  (share freely)           : {pub_path}")
    print(f"Fingerprint: {pretty_fp(ident.fingerprint)}")
    print("Confirm this fingerprint with the other party over a trusted channel.")
    return 0


def cmd_encrypt(args) -> int:
    recipients = [PublicIdentity.load(p) for p in args.recipient]
    signer = PrivateIdentity.load(args.sign_with, _passphrase(args)) if args.sign_with else None
    encrypt_file(
        args.infile, args.output, recipients, signer, chunk_size=args.chunk_size,
        overwrite=args.force,
    )
    print(f"Encrypted -> {args.output}")
    print("Recipients: " + ", ".join(f"{r.name or '?'} [{pretty_fp(r.fingerprint)[:9]}]" for r in recipients))
    if signer:
        print(f"Signed by : {signer.name or '?'} [{pretty_fp(signer.fingerprint)[:9]}]")
    return 0


def cmd_decrypt(args) -> int:
    ident = PrivateIdentity.load(args.key, _passphrase(args))
    sender = PublicIdentity.load(args.sender) if args.sender else None
    info = decrypt_file(
        args.infile, args.output, ident, sender=sender,
        allow_unverified=args.unverified_ok, overwrite=args.force,
    )
    print(f"Decrypted -> {args.output} ({info['plaintext_bytes']} bytes)")
    if info["signature_verified"]:
        print(f"Signature verified: signed by {pretty_fp(info['signed_by'])}")
    elif info["signed_by"]:
        print("WARNING: file is signed but the signature was NOT verified.")
    else:
        print("Note: file is not signed, so the sender is not authenticated.")
    return 0


def cmd_inspect(args) -> int:
    info = inspect_file(args.infile)
    print(f"Suite      : {info['suite']}")
    print(f"Chunk size : {info['chunk_size']}")
    print(f"Size       : {info['size_bytes']} bytes")
    print(f"Signed by  : {pretty_fp(info['signed_by']) if info['signed_by'] else 'not signed'}")
    print("Recipients :")
    for fp in info["recipients"]:
        print(f"  - {pretty_fp(fp)}")
    return 0


def cmd_fingerprint(args) -> int:
    pub = PublicIdentity.load(args.pubfile)
    print(f"{pub.name or '?'}: {pretty_fp(pub.fingerprint)}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="labvault",
        description="LAB Vault: hybrid post-quantum file encryption "
        "(ML-KEM-768 + X25519 + AES-256-GCM, ML-DSA-65 signatures). UNAUDITED.",
    )
    sub = p.add_subparsers(dest="cmd", required=True)

    def add_pw(sp):
        sp.add_argument("--passphrase-file", help="read passphrase from this file "
                        "(else $LABVAULT_PASSPHRASE, else prompt)")

    k = sub.add_parser("keygen", help="create a new identity (key pair)")
    k.add_argument("--name", required=True, help="identity name, e.g. acme-bank")
    k.add_argument("--out-dir", default=".", help="where to write the key files")
    add_pw(k)
    k.set_defaults(fn=cmd_keygen)

    e = sub.add_parser("encrypt", help="encrypt a file for one or more recipients")
    e.add_argument("infile")
    e.add_argument("-o", "--output", required=True)
    e.add_argument("-r", "--recipient", action="append", required=True,
                   help="recipient public key file (repeatable)")
    e.add_argument("--sign-with", help="your private key file, to sign the file")
    e.add_argument("--chunk-size", type=int, default=DEFAULT_CHUNK)
    e.add_argument("--force", action="store_true", help="overwrite output if it exists")
    add_pw(e)
    e.set_defaults(fn=cmd_encrypt)

    d = sub.add_parser("decrypt", help="decrypt a file addressed to you")
    d.add_argument("infile")
    d.add_argument("-o", "--output", required=True)
    d.add_argument("--key", required=True, help="your private key file")
    d.add_argument("--sender", help="sender's public key file, to verify the signature")
    d.add_argument("--unverified-ok", action="store_true",
                   help="decrypt a signed file without verifying who signed it")
    d.add_argument("--force", action="store_true", help="overwrite output if it exists")
    add_pw(d)
    d.set_defaults(fn=cmd_decrypt)

    i = sub.add_parser("inspect", help="show a file's public header (no keys needed)")
    i.add_argument("infile")
    i.set_defaults(fn=cmd_inspect)

    f = sub.add_parser("fingerprint", help="show a public key's fingerprint")
    f.add_argument("pubfile")
    f.set_defaults(fn=cmd_fingerprint)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.fn(args)
    except VaultError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    except FileNotFoundError as exc:
        print(f"error: file not found: {exc.filename}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
