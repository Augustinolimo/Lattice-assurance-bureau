import io
import os
import stat
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from labvault import core  # noqa: E402
from labvault.core import (  # noqa: E402
    PrivateIdentity,
    PublicIdentity,
    VaultError,
    decrypt_file,
    encrypt_file,
    inspect_file,
)

ROOT = os.path.join(os.path.dirname(__file__), "..")
SMALL = 1024  # small chunk size so tests exercise multi-chunk logic


class Base(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.alice = PrivateIdentity.generate("alice")
        cls.bob = PrivateIdentity.generate("bob")
        cls.eve = PrivateIdentity.generate("eve")

    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.d = self._tmp.name

    def tearDown(self):
        self._tmp.cleanup()

    def p(self, name):
        return os.path.join(self.d, name)

    def write(self, name, data: bytes) -> str:
        path = self.p(name)
        with open(path, "wb") as f:
            f.write(data)
        return path

    def read(self, path) -> bytes:
        with open(path, "rb") as f:
            return f.read()

    def enc(self, data: bytes, rcpts, signer=None, chunk=SMALL, name="f"):
        src = self.write(name + ".txt", data)
        out = self.p(name + ".lv")
        encrypt_file(src, out, [r.public() for r in rcpts], signer, chunk_size=chunk)
        return out


class RoundTrip(Base):
    def test_sizes_roundtrip(self):
        for n in (0, 1, 15, 16, SMALL - 1, SMALL, SMALL + 1, 2 * SMALL, 5 * SMALL + 17):
            with self.subTest(size=n):
                data = os.urandom(n)
                ct = self.enc(data, [self.alice], name=f"s{n}")
                out = self.p(f"o{n}")
                info = decrypt_file(ct, out, self.alice)
                self.assertEqual(self.read(out), data)
                self.assertEqual(info["plaintext_bytes"], n)

    def test_default_chunk_size_multi_chunk(self):
        data = os.urandom(core.DEFAULT_CHUNK * 2 + 123)
        ct = self.enc(data, [self.alice], chunk=core.DEFAULT_CHUNK)
        out = self.p("o")
        decrypt_file(ct, out, self.alice)
        self.assertEqual(self.read(out), data)

    def test_ciphertext_is_randomized(self):
        data = b"same plaintext"
        a = self.read(self.enc(data, [self.alice], name="a"))
        b = self.read(self.enc(data, [self.alice], name="b"))
        self.assertNotEqual(a, b)
        self.assertNotIn(data, a)

    def test_multi_recipient(self):
        data = os.urandom(3000)
        ct = self.enc(data, [self.alice, self.bob])
        for who in (self.alice, self.bob):
            out = self.p("o_" + who.name)
            decrypt_file(ct, out, who)
            self.assertEqual(self.read(out), data)
        self.assertEqual(len(inspect_file(ct)["recipients"]), 2)

    def test_wrong_recipient_rejected(self):
        ct = self.enc(b"secret", [self.alice])
        out = self.p("o")
        with self.assertRaises(VaultError):
            decrypt_file(ct, out, self.eve)
        self.assertFalse(os.path.exists(out))

    def test_no_overwrite_by_default(self):
        ct = self.enc(b"x", [self.alice])
        out = self.write("exists", b"keep me")
        with self.assertRaises(VaultError):
            decrypt_file(ct, out, self.alice)
        self.assertEqual(self.read(out), b"keep me")

    def test_primitive_sizes(self):
        pub = self.alice.public()
        self.assertEqual(len(pub.mlkem768), 1184)
        self.assertEqual(len(pub.mldsa65), 1952)
        self.assertEqual(len(pub.x25519), 32)


class Tamper(Base):
    def _flip(self, path, offset_from_end=None, offset=None):
        data = bytearray(self.read(path))
        i = offset if offset is not None else len(data) - offset_from_end
        data[i] ^= 0x01
        with open(path, "wb") as f:
            f.write(data)

    def _assert_fails_clean(self, ct):
        out = self.p("o")
        with self.assertRaises(VaultError):
            decrypt_file(ct, out, self.alice)
        self.assertFalse(os.path.exists(out), "no plaintext may remain after failure")
        leftovers = [n for n in os.listdir(self.d) if n.startswith(".labvault-")]
        self.assertEqual(leftovers, [])

    def test_bit_flip_in_ciphertext(self):
        ct = self.enc(os.urandom(4000), [self.alice])
        self._flip(ct, offset_from_end=100)
        self._assert_fails_clean(ct)

    def test_bit_flip_in_first_chunk(self):
        ct = self.enc(os.urandom(4000), [self.alice])
        with open(ct, "rb") as f:
            _, _, start = core.read_header(f)
        self._flip(ct, offset=start + 5)
        self._assert_fails_clean(ct)

    def test_header_tamper(self):
        ct = self.enc(os.urandom(2000), [self.alice])
        self._flip(ct, offset=len(core.MAGIC) + 4 + 30)
        self._assert_fails_clean(ct)

    def test_truncation_dropping_last_chunk(self):
        data = os.urandom(3 * SMALL)
        ct = self.enc(data, [self.alice])
        raw = self.read(ct)
        with open(ct, "wb") as f:
            f.write(raw[: -(SMALL + core.TAG_LEN)])  # drop the final chunk exactly
        self._assert_fails_clean(ct)

    def test_truncation_partial(self):
        ct = self.enc(os.urandom(3 * SMALL), [self.alice])
        raw = self.read(ct)
        with open(ct, "wb") as f:
            f.write(raw[:-7])
        self._assert_fails_clean(ct)

    def test_appended_garbage(self):
        ct = self.enc(os.urandom(2 * SMALL), [self.alice])
        with open(ct, "ab") as f:
            f.write(b"\x00" * 40)
        self._assert_fails_clean(ct)

    def test_chunk_reordering(self):
        ct = self.enc(os.urandom(4 * SMALL), [self.alice])
        raw = bytearray(self.read(ct))
        with open(ct, "rb") as f:
            _, _, start = core.read_header(f)
        full = SMALL + core.TAG_LEN
        c0, c1 = bytes(raw[start : start + full]), bytes(raw[start + full : start + 2 * full])
        raw[start : start + full], raw[start + full : start + 2 * full] = c1, c0
        with open(ct, "wb") as f:
            f.write(raw)
        self._assert_fails_clean(ct)

    def test_not_a_vault_file(self):
        junk = self.write("junk", b"hello world" * 10)
        with self.assertRaises(VaultError):
            decrypt_file(junk, self.p("o"), self.alice)


class Signatures(Base):
    def test_signed_roundtrip_verified(self):
        data = os.urandom(5000)
        ct = self.enc(data, [self.bob], signer=self.alice)
        out = self.p("o")
        info = decrypt_file(ct, out, self.bob, sender=self.alice.public())
        self.assertTrue(info["signature_verified"])
        self.assertEqual(self.read(out), data)

    def test_signed_file_requires_explicit_choice(self):
        ct = self.enc(b"hi", [self.bob], signer=self.alice)
        with self.assertRaises(VaultError):
            decrypt_file(ct, self.p("o"), self.bob)
        info = decrypt_file(ct, self.p("o2"), self.bob, allow_unverified=True)
        self.assertFalse(info["signature_verified"])

    def test_wrong_sender_rejected(self):
        ct = self.enc(b"hi", [self.bob], signer=self.alice)
        with self.assertRaises(VaultError):
            decrypt_file(ct, self.p("o"), self.bob, sender=self.eve.public())

    def test_signature_detects_modification_before_release(self):
        ct = self.enc(os.urandom(3000), [self.bob], signer=self.alice)
        raw = bytearray(self.read(ct))
        raw[-core.TAG_LEN - 3309 - 5] ^= 1  # inside the ciphertext, before the signature
        with open(ct, "wb") as f:
            f.write(raw)
        out = self.p("o")
        with self.assertRaises(VaultError) as cm:
            decrypt_file(ct, out, self.bob, sender=self.alice.public())
        self.assertIn("SIGNATURE", str(cm.exception))
        self.assertFalse(os.path.exists(out))

    def test_forged_signature_bytes(self):
        ct = self.enc(b"data" * 500, [self.bob], signer=self.alice)
        raw = bytearray(self.read(ct))
        raw[-10] ^= 1
        with open(ct, "wb") as f:
            f.write(raw)
        with self.assertRaises(VaultError):
            decrypt_file(ct, self.p("o"), self.bob, sender=self.alice.public())

    def test_sender_given_but_file_unsigned(self):
        ct = self.enc(b"hi", [self.bob])
        with self.assertRaises(VaultError):
            decrypt_file(ct, self.p("o"), self.bob, sender=self.alice.public())

    def test_inspect_reports_signer(self):
        ct = self.enc(b"hi", [self.bob], signer=self.alice)
        info = inspect_file(ct)
        self.assertEqual(info["signed_by"], self.alice.fingerprint)


class KeyFiles(Base):
    def test_save_load_roundtrip_and_permissions(self):
        path = self.p("alice.key.json")
        self.alice.save(path, "correct horse battery staple")
        mode = stat.S_IMODE(os.stat(path).st_mode)
        self.assertEqual(mode, 0o600)
        loaded = PrivateIdentity.load(path, "correct horse battery staple")
        self.assertEqual(loaded.fingerprint, self.alice.fingerprint)
        ct = self.enc(b"via loaded key", [self.alice])
        out = self.p("o")
        decrypt_file(ct, out, loaded)
        self.assertEqual(self.read(out), b"via loaded key")

    def test_wrong_passphrase(self):
        path = self.p("k.json")
        self.alice.save(path, "correct horse battery staple")
        with self.assertRaises(VaultError):
            PrivateIdentity.load(path, "wrong passphrase here")

    def test_key_file_tamper_detected(self):
        import json

        path = self.p("k.json")
        self.alice.save(path, "correct horse battery staple")
        with open(path) as f:
            d = json.load(f)
        d["fingerprint"] = "00" * 32
        with open(path, "w") as f:
            json.dump(d, f)
        with self.assertRaises(VaultError):
            PrivateIdentity.load(path, "correct horse battery staple")

    def test_public_key_file_roundtrip_and_integrity(self):
        import json

        path = self.p("alice.pub.json")
        self.alice.public().save(path)
        self.assertEqual(PublicIdentity.load(path).fingerprint, self.alice.fingerprint)
        with open(path) as f:
            d = json.load(f)
        d["x25519"] = d["x25519"][:-4] + "AAAA"
        with open(path, "w") as f:
            json.dump(d, f)
        with self.assertRaises(VaultError):
            PublicIdentity.load(path)

    def test_refuses_to_overwrite_key(self):
        path = self.p("k.json")
        self.alice.save(path, "correct horse battery staple")
        with self.assertRaises(FileExistsError):
            self.alice.save(path, "correct horse battery staple")


class CLI(Base):
    def test_end_to_end(self):
        env_path = {"PYTHONPATH": ROOT}

        def run(*a, pw="correct horse battery staple"):
            env = dict(os.environ, LABVAULT_PASSPHRASE=pw, **env_path)
            return subprocess.run(
                [sys.executable, "-m", "labvault", *a],
                capture_output=True, text=True, cwd=ROOT, env=env,
            )

        r = run("keygen", "--name", "alice", "--out-dir", self.d)
        self.assertEqual(r.returncode, 0, r.stderr)
        r = run("keygen", "--name", "bob", "--out-dir", self.d)
        self.assertEqual(r.returncode, 0, r.stderr)

        plain = self.write("report.txt", b"Q3 customer records\n" * 5000)
        enc = self.p("report.lv")
        r = run("encrypt", plain, "-o", enc, "-r", self.p("bob.pub.json"),
                "--sign-with", self.p("alice.key.json"))
        self.assertEqual(r.returncode, 0, r.stderr)

        r = run("inspect", enc)
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("Signed by", r.stdout)

        out = self.p("report.out")
        r = run("decrypt", enc, "-o", out, "--key", self.p("bob.key.json"))
        self.assertEqual(r.returncode, 2)  # signed file needs explicit sender choice
        self.assertFalse(os.path.exists(out))

        r = run("decrypt", enc, "-o", out, "--key", self.p("bob.key.json"),
                "--sender", self.p("alice.pub.json"))
        self.assertEqual(r.returncode, 0, r.stderr)
        self.assertIn("Signature verified", r.stdout)
        self.assertEqual(self.read(out), self.read(plain))

        r = run("decrypt", enc, "-o", self.p("x"), "--key", self.p("alice.key.json"),
                "--unverified-ok")
        self.assertEqual(r.returncode, 2)  # alice is not a recipient
        self.assertIn("not an intended recipient", r.stderr)

        r = run("decrypt", enc, "-o", self.p("y"), "--key", self.p("bob.key.json"),
                "--sender", self.p("alice.pub.json"), pw="wrong passphrase!!")
        self.assertEqual(r.returncode, 2)
        self.assertIn("wrong passphrase", r.stderr)


if __name__ == "__main__":
    unittest.main(verbosity=2)
