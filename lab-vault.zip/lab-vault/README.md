# LAB Vault

Hybrid post-quantum file encryption for **Lattice Assurance Bureau**.

> **STATUS: v0.1, UNAUDITED.** All 28 included tests pass, but nobody outside
> this project has reviewed the design or code. Do not use it for real customer
> data, and do not market it as "secure" or "quantum-proof", until an independent
> cryptographic audit is done (see *Before you sell this*).

## What it does

Encrypts files so that only the intended recipient(s) can read them, and
optionally signs them so the recipient can prove who sent them.

| Job | Algorithm | Standard |
|---|---|---|
| Protect the file key (resists future quantum computers) | **ML-KEM-768** + **X25519**, combined (hybrid) | NIST FIPS 203 |
| Encrypt the data | **AES-256-GCM**, 64 KiB chunks, streaming | NIST SP 800-38D |
| Prove who sent it | **ML-DSA-65** over a SHA3-512 digest | NIST FIPS 204 |
| Protect private keys at rest | scrypt (N=2^17) + AES-256-GCM | RFC 7914 |

"Hybrid" means an attacker has to break **both** X25519 and ML-KEM to recover
the file key. That protects against "harvest now, decrypt later" attacks, where
encrypted data is stolen today and decrypted once quantum computers exist.

The primitives come from the Python `cryptography` package (OpenSSL backend).
No custom crypto primitives are implemented here. The *composition* (how the
pieces are combined) and the file format are this project's own.

## Install

Requires Python 3.10+ and `cryptography >= 50.0.1` (first versions that include
ML-KEM and ML-DSA; developed and tested on 50.0.1).

```
pip install "cryptography>=50.0.1"
```

No other dependencies. Run from this folder.

## Use

```bash
# 1. Each party creates an identity (a private key file + a public key file)
python -m labvault keygen --name acme-bank --out-dir keys/
python -m labvault keygen --name lab        --out-dir keys/

# Verify fingerprints out-of-band (phone call, in person) before trusting a public key
python -m labvault fingerprint keys/acme-bank.pub.json

# 2. Lattice Assurance Bureau encrypts a report for the client, and signs it
python -m labvault encrypt report.pdf -o report.pdf.lv \
    -r keys/acme-bank.pub.json --sign-with keys/lab.key.json

# 3. The client decrypts it and verifies it came from LAB
python -m labvault decrypt report.pdf.lv -o report.pdf \
    --key keys/acme-bank.key.json --sender keys/lab.pub.json

# See who a file is for (no keys needed)
python -m labvault inspect report.pdf.lv
```

- Encrypt for several recipients by repeating `-r`.
- Passphrases come from a prompt, `--passphrase-file`, or `$LABVAULT_PASSPHRASE`.
- A signed file will not decrypt unless you pass `--sender` (verify) or
  `--unverified-ok` (skip verification on purpose). Verification happens
  **before** any plaintext is written.
- Output is written to a temp file and moved into place only after every chunk
  authenticates, so a tampered or truncated file never leaves partial plaintext.
- Existing files are never overwritten unless you pass `--force`.

Use as a library:

```python
from labvault import PrivateIdentity, encrypt_file, decrypt_file
```

## Run the tests

```
python -m unittest discover -s tests -v
```

They cover round trips (empty files, exact chunk boundaries, multi-chunk),
multi-recipient, wrong key, bit flips, header tampering, truncation, chunk
reordering, appended data, forged signatures, wrong sender, passphrase errors,
and an end-to-end CLI run.

## File format (v1)

```
"LABVAULT" | header_len (u32 BE) | header (canonical JSON) | chunk_1 ... chunk_n | [ML-DSA-65 signature]
```

- Header holds the suite name, chunk size, a 7-byte nonce prefix, and one entry
  per recipient (ephemeral X25519 public key, ML-KEM ciphertext, wrapped file key).
- Chunk nonce = prefix || counter (4 bytes) || final-flag (1 byte), so chunks
  cannot be reordered, dropped from the end, or extended undetected.
- Each chunk is authenticated against a hash of the header.
- The hybrid key combiner is HKDF-SHA256 over both shared secrets, salted with a
  hash of the full transcript (ephemeral key, KEM ciphertext, recipient public keys).

## Known limitations (be honest about these with customers)

- **Unaudited.** The biggest one. See below.
- **No key revocation, rotation, or directory.** Trust in a public key comes
  only from checking its fingerprint yourself.
- **No forward secrecy against recipient key theft.** If a recipient's private
  key (and passphrase) is stolen, every file ever encrypted to it can be read.
- **Metadata is visible:** file size (rounded by chunk), number of recipients,
  recipient and signer fingerprints. No filenames are stored.
- **Passphrase strength matters.** The private key file is only as strong as its
  passphrase (12+ characters enforced; much longer recommended).
- **Plaintext handling is not hardened:** secrets may linger in process memory,
  swap, or on disk where you save decrypted files. No HSM support.
- **Python and OpenSSL are not constant-time-audited or FIPS-validated here.**
- **Not a wallet or blockchain product.** It has nothing to do with `kqc-pqaccount`.

## Before you sell this

1. Independent cryptographic review of `labvault/core.py` (about 540 lines) by a
   firm that audits cryptography, plus a penetration test.
2. Decide on a key-management story customers can actually operate (HSM/KMS,
   backup and recovery, rotation).
3. Consider FIPS 140-3 validated modules if you target banks or government.
4. Wording: until audited, say "built on NIST post-quantum standards (FIPS 203/204)",
   not "unbreakable" or "quantum-proof".
5. Have a Kenyan lawyer review customer contracts, liability limits, and Data
   Protection Act obligations (ODPC registration as a data processor, if applicable).

## License

Choose one before distributing (the earlier `kqc-pqaccount` repo used MIT).
